-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 54.180.135.126    Database: gogoma_test
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `birth_date` varchar(255) DEFAULT NULL,
  `birth_year` varchar(255) DEFAULT NULL,
  `clothing_size` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `gender` enum('FEMALE','MALE','NONE') DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `total_distance` int NOT NULL,
  `detail_address` varchar(255) DEFAULT NULL,
  `road_address` varchar(255) DEFAULT NULL,
  `kakao_id` bigint NOT NULL COMMENT '카카오 사용자 고유 ID',
  `fcm_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `kakao_id` (`kakao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (5,'0831','1998','100','2025-01-31 02:27:49.154985','dydgus0831@naver.com','MALE','김용현','+82 10-7509-4198','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg',230,'우리집','역삼로',3895882948,NULL),(56,'1205','1998','100','2025-02-14 17:46:19.251206','potential1205@naver.com','MALE','이재훈','+82 10-2823-1302','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg',80150,'202','서울 성동구 용답동 13-22',3900456033,NULL),(76,'1031','1996','','2025-02-18 13:05:27.634094','gernica10@naver.com','MALE','이주호','+82 10-6685-9610','http://k.kakaocdn.net/dn/b8Mmzq/btsL9sWmrXJ/9yWFHF1KRCaiuOgNtkceYK/img_640x640.jpg',20180,'','',3914967980,'fNnpR16BT0CF5pTk1_rSDM:APA91bHzcyo5i-WkpDjrELdELlAuPGmFjfEQee_JXxCn6UwWFI0PUWALSzI-EsdFa0qvVhNLgwUyGcDjHMUmMyRmsnbhes-eKXYlMzCcZzSP1Rky3sa17bM'),(90,'1027','1994','','2025-02-19 14:45:58.958094','hogik1027@naver.com','FEMALE','박민경','+82 10-9916-3585','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg',160210,'','',3911281442,'fzYGTb7zTC-604qIeUFIBe:APA91bFYp0DGltec8TmpZKX47Q1qaDc_lU0ukH1tEKqKjczsOHkDmbDBHdY0bKKOMnu34ZtGKrSau7hYNNbqLRotQm9qA9HbvQUV3d_DxXIDJkwqEO0Yq68'),(91,'1112','1999','90','2025-02-19 18:28:03.842016','qwa0203@gmail.com','FEMALE','백지민','+82 10-6258-9818','http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg',10280,'10','경기 의왕시 윗새우대북길 3',3909662894,'c_h7q8ZNTIuUKS4yZRU-R3:APA91bGB2uAIylfaQem_l7ytxzSryzP2vfSIjkKRd3-xZ6mSA2j5qqp4ne91znJUbJXOSqfUb8tVzCyCzM3UqLHNdAUwOGYCJ66x_r8uqB5-JXtfaNS2GQc');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-20 21:01:57
