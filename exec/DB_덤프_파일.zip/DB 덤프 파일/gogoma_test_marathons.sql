-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 54.180.135.126    Database: gogoma_test
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `marathons`
--

DROP TABLE IF EXISTS `marathons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marathons` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_bank` varchar(255) DEFAULT NULL,
  `account_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `course_image` varchar(255) DEFAULT NULL,
  `form_type` int NOT NULL,
  `form_url` varchar(255) DEFAULT NULL,
  `info_image` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `marathon_status` enum('CLOSED','FINISHED','OPEN') DEFAULT NULL,
  `qualifications` varchar(255) DEFAULT NULL,
  `race_start_time` datetime(6) DEFAULT NULL,
  `registration_end_date_time` datetime(6) DEFAULT NULL,
  `registration_start_date_time` datetime(6) DEFAULT NULL,
  `thumbnail_image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `view_count` int NOT NULL,
  `city` varchar(255) DEFAULT NULL,
  `month` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `home_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marathons`
--

LOCK TABLES `marathons` WRITE;
/*!40000 ALTER TABLE `marathons` DISABLE KEYS */;
INSERT INTO `marathons` VALUES (23,'하나은행','전국마라톤협회','657-910009-90204',NULL,2,'http://www.run1080.com/new/mini/index.php?code=1460',NULL,'금산인삼엑스포주차장','OPEN','','2025-03-23 09:00:00.000000',NULL,NULL,'https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/a142f710-b896-4df6-9703-f2fbe772b89c.jpg','금산마라톤대회',0,'충청남도','3','2025','금산읍','금산군',''),(24,'농협','이영애','301-0163-4152-91','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/course/8b9d96bd-466c-44be-a6cb-3b406dfb6491.png',1,'','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/info/f6c85c7f-78f5-4465-9a5b-15bee44d7bec.png','화순군 청풍면 풍암리 93-9번지(화순파크골프장 일원)','OPEN','참가자 완주 제한시간 기준 확인','2025-01-02 08:30:00.000000','2025-02-17 23:59:59.000000','2025-01-13 00:00:00.000000','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/e2987fd9-6e66-44fb-a797-489eb7d9a3af.png','제60회 광주일보 3.1절 전국마라톤대회',0,'전라남도','3','2025','청풍면','화순군',NULL),(25,'농협','이태재','703-12-333174','',1,'','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/info/16ab38b5-ec0f-4497-b495-39bda32efafa.png','낙성대공원주차장(서울 관악구 낙성대로 77)','OPEN','','2025-03-02 08:00:00.000000','2025-03-01 17:00:00.000000',NULL,'https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/b0c02736-284a-4170-b80f-6b010e4f928b.png','서울 관악산트레일 대회',0,'서울특별시','3','2025','봉천동','관악구',NULL),(26,'농협','이태재','703-12-333-174','',1,'','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/info/ee73b627-bc65-4385-ad53-a762294c10e2.png','부산영도 남항대교 수변야외공연장','OPEN','','2025-03-23 08:00:00.000000','2025-03-22 17:00:00.000000',NULL,'https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/c35226c8-af4b-49fa-8c60-79c1a26e3ac6.png','부산 영도태종대트레일',0,'부산광역시','3','2025','남항동','영도구',NULL),(27,'농협','이태재','703-12-333174','',1,'','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/info/02bfe68c-8270-4efe-8d57-387f38ca9a7f.png','통영항여객선터미널','OPEN','','2025-04-06 09:00:00.000000','2025-04-05 17:00:00.000000',NULL,'https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/dd46aeb3-7ea1-42da-a6b2-1a3c89bd2201.jpg','통영 한산도트레일런',0,'경상남도','4','2025','서호동','통영시',NULL),(28,'농협','이태재','703-12-333174','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/course/9af42d4d-c241-4be3-97cc-6b3ab548de94.jpg',1,'','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/info/4f9993a0-f485-4f9d-bb68-8bdae8ab10c2.png','출발/소야고개, 도착/능성재(무정식당)','OPEN','','2025-04-13 06:00:00.000000','2025-03-31 17:00:00.000000',NULL,'https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/b110fb21-ad1a-4bed-a501-e02e4aeb1a20.jpg','팔공산 소능총주32k',0,'대구광역시','4','2025','중대동','동구',NULL),(29,'농협','이태재','703-01-397307','',1,'','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/info/046bcbc4-7c3d-40db-8f35-adc7ac8972cf.png','청계산근린광장 공영주차장 (청계산입구역에서 300m)','OPEN','','2025-04-27 08:00:00.000000','2025-04-26 17:00:00.000000',NULL,'https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/449ca278-992d-46df-8eb3-cdf19a9c4c20.jpg','서울 청계산트레일',0,'서울특별','4','2025','원지동','서처구',NULL),(30,'농협','이태재','703-01-397311','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/course/67ec201e-8189-4f11-bf8f-555ea138f9c1.jpg',1,'','https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/info/df443841-fea6-4975-9fdd-93d342380049.png','밀양보트장(밀양강둔치)','OPEN','입금자 선착순 50명 제한','2025-02-19 08:00:00.000000','2025-05-03 17:00:00.000000',NULL,'https://gogomarathon.s3.ap-northeast-2.amazonaws.com/marathon/thumbnail/057079bd-8771-491a-a568-d0c56649130e.jpg','밀양아리랑 트레일런',0,'경상남도','5','2025','삼문동','밀양시',NULL),(32,'국민은행','SSAFY','703-01-397311',NULL,1,NULL,NULL,'자양역','OPEN',NULL,'2025-02-21 10:59:13.000000',NULL,NULL,NULL,'2025 제 12회 SSAFY 공통 마라톤 대회',0,'서울특별시','2','2025','광진구','자양동',NULL),(33,'하나은행','전국마라톤협회','657-910035-22705',NULL,0,NULL,NULL,'해피700센터(강원 평창군 대관령면 횡계리 310-23)','FINISHED',NULL,'2025-02-01 10:30:00.000000',NULL,NULL,NULL,'2025 평창 대관령 알몸 마라톤',0,'강원도','2','2025','평창군','대관령면',NULL),(34,'하나은행','장영기','657-910579-29107',NULL,0,NULL,NULL,NULL,NULL,NULL,'2025-02-15 09:00:00.000000',NULL,NULL,NULL,'2025 전마협 청주 무심천 투데이 마라톤',0,'충청북도','2','2025','청주시',NULL,NULL);
/*!40000 ALTER TABLE `marathons` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-20 21:01:59
